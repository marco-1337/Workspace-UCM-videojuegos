#include "Scene.h"

class Scene0 : public Scene
{
public:
	void init() override;
};