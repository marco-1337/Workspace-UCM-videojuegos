#include "Scene.h"

// Apartado 56
class Scene4 : public Scene
{
public:
	void init() override;
};