#pragma once

#include "ColorMaterialEntity.h"

// Apartado 60
class IndexedBox : public ColorMaterialEntity
{
public:
	explicit IndexedBox(GLdouble length);
};
