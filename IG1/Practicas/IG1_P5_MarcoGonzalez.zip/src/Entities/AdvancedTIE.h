#pragma once

#include "CompoundEntity.h"

// Apartado 66
class AdvancedTIE : public CompoundEntity
{
public:
    explicit AdvancedTIE(GLdouble scale, Texture* tex);
};