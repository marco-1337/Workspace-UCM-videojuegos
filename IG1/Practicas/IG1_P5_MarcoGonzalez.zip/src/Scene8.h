#include "Scene.h"

#include <vector>

class CompoundEntity;

class Abs_Entity;

// Apartado 67
class Scene8 : public Scene
{
public:
	void init() override;
};