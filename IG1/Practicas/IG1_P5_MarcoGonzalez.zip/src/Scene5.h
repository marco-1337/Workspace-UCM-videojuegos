#include "Scene.h"

// Apartado 56
class Scene5 : public Scene
{
public:
	void init() override;
};